<?php ?>
<!DOCTYPE html>
<html>
<head>
    <title>Libro de visitas</title>
</head>
<body>
    <h1>Bienvenido</h1>
    <p><a href="libro_visitas.php">Ver libro de visitas  </a></p>
    <p><a href="nueva_visita.php" >Escribir un comentario</a></p>
</body>
</html>